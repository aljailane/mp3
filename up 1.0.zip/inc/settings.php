<?php
/*
Project Name: Next Auto Index
Project URI: http://wapindex.mirazmac.info
Project Version: 3.2
Licence: GPL v3
*/
## This is a modified version of Master Autoindex. So all source rights goes to ionutvmi ##

$set->db_name = "4lju_19463625_site";
$set->db_user = "4lju_19463625";
$set->db_host = "sql100.alju.ga";
$set->db_pass = "050935";


$set->name = "دار الاحبة"; // site name
$set->url = "http://geny.alju.ga/"; // site url
$set->logo = "http://geny.alju.ga/logo.png"; // logo url (full url http://site.com/)
$set->perpage = "10"; // how many records per page
define("MAI_PREFIX","nxt_gsjfwj");