<?php
/*
Project Name: Next Auto Index
Project URI: http://wapindex.mirazmac.info
Project Version: 3.2
Licence: GPL v3
*/
## This is a modified version of Master Autoindex. So all source rights goes to ionutvmi ##

$set->db_name = "4lju_19203492_file";
$set->db_user = "4lju_19203492";
$set->db_host = "sql310.alju.ga";
$set->db_pass = "050935";


$set->name = "دار الاحبة"; // site name
$set->url = "http://dv.regup.ga/"; // site url
$set->logo = "http://dv.regup.ga/logo.png"; // logo url (full url http://site.com/logo.png)
$set->perpage = "10"; // how many records per page
define("MAI_PREFIX","nxt_gsjfwj");